function horloge() 
   {
var ladate=new Date();
// Je formate  les minutes secondes et heures sur deux chiffres.
var minutes = (ladate.getMinutes()<10?'0':'') + ladate.getMinutes() ;
var secondes = (ladate.getSeconds()<10?'0':'') + ladate.getSeconds() ;
var heures = (ladate.getHours()<10?'0':'') + ladate.getHours() ;
var jour = ladate.getDate();
var mois =  ladate.getMonth()+1;
var annee = ladate.getYear()+1900;

var element = document.getElementById("dateheurefoot");
    element.innerHTML = "Nous sommes le  <em  Class='Rouge'>"+jour+"/"+mois+"/"+annee+"</em> et il est <em  Class='Rouge'>"+heures+":"+minutes+":"+secondes+"</em>";
   }
