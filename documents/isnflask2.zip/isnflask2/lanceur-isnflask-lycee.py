#!/usr/bin/python3
# -∗- coding: utf-8 -∗-

filepy="isnflask\\isnflask.py"
lienpy="C:\\ProgramData\\Miniconda3\\python.exe"

import subprocess
import os
user= os.environ["USERNAME"]                  # nom de USER
diruser=os.path.join('U:\\', user)            # adresse absolue du répertoire de USER
filepy=os.path.join(diruser,filepy)           # adresse absolue du fichier isnflask.py
dirfilepy=os.path.dirname(filepy)             # adresse absolue répertoire du fichier isnflask.py
os.chdir(dirfilepy)                           # On se déplace dans le dossier  inutile mais j'aime  mieux
subprocess.run([lienpy, filepy])              # On  execute  le fichier  isnflask

