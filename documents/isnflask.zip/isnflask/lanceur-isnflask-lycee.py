#!/usr/bin/python3
# -∗- coding: utf-8 -∗-

lienpy="C:\\ProgramData\\Miniconda3\\python.exe"
filepy="isnflask\\isnflask.py"

#  on  importe
import subprocess
import os

user= os.environ["USERNAME"]
diruser=os.path.join('U:\\', user)
filepy=os.path.join(diruser,filepy)
print(filepy)
dirfilepy='\\'.join(filepy.split('\\')[:-1])
print(dirfilepy)

os.chdir(dirfilepy)

subprocess.run([lienpy, filepy]) 
